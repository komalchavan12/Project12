package com.cg.bank.dao;

import java.util.List;
import java.util.Map;

import com.cg.bank.bean.Account;
import com.cg.bank.bean.Transaction;
import com.cg.bank.bean.Wallet;
import com.cg.bank.exception.AccountException;

public interface IAccountDAO {

	public double getaccountbalance(int account_number1);
	public double getwalletbalance(int account_number1);

	double deposite(int Account_number11, double depositeamount) throws AccountException;

	double withdraw(int account_number111, double amountwithdraw) throws AccountException;
	public void addnewAccount(Account a);

	String Wallettowallet(int account_number4, int reciever_account_number, double amount1);

	String Accounttowallet(int account_number5, double amount11);

	String Wallettoaccount(int account_number6, double amount2);
	public List<Transaction> printtransaction(int account_number);
	


}
