package com.cg.bank.service;

import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import com.cg.bank.bean.Account;
import com.cg.bank.bean.Transaction;
import com.cg.bank.dao.AccountDAOImpl;
import com.cg.bank.dao.IAccountDAO;
import com.cg.bank.exception.AccountException;


public class AccountServiceImpl<Wallet> implements IAccountService {
	IAccountDAO dao=new AccountDAOImpl();

	@Override
	public void validateUserName(String username) throws AccountException {
		String NameRegex="[A-Z]{1}[a-z]{2,8}";
		if(Pattern.matches(NameRegex, username)==false) {
		throw new AccountException("Username start with capital letter");	
	}
	}

	@Override
	public void validatePassword(String password) throws AccountException {
		String PasswordRegex="[0-9]{5}";
		if(Pattern.matches(PasswordRegex, password)==false) {
		throw new AccountException("Password contains 5 digits");		
	}
	}

	@Override
	public void validateMobileNo(String mobileNo) throws AccountException {
		String MobileRegex="[9|8|7]{1}[0-9]{9}";
		if(Pattern.matches(MobileRegex, mobileNo)==false) {
		throw new AccountException("Mobile number should contains 10 digits");
		
	}

	}

	@Override
	public void validateAccount_number(int account_number) throws AccountException {
		String AccountRegEx = "[0-9]+";
		if (Pattern.matches(AccountRegEx, String.valueOf(account_number)) == false) {
			throw new AccountException("orderid should contain only digits");
		}	
	}
	public void addnewAccount(Account a){
	dao.addnewAccount(a);
		
	}
	@Override
	public double getaccountbalance(int account_number1) {
		// TODO Auto-generated method stub
		return dao.getaccountbalance(account_number1);
	}

	@Override
	public double getwalletbalance(int account_number1) {
		// TODO Auto-generated method stub
		return dao.getwalletbalance(account_number1);
	}

	
	@Override
	public double deposite(int Account_number11, double depositeamount) throws AccountException {
		// TODO Auto-generated method stub
		return dao.deposite(Account_number11,depositeamount);
	}
	@Override
	public double withdraw(int account_number111, double amountwithdraw) throws AccountException {
		// TODO Auto-generated method stub
		return dao.withdraw(account_number111,amountwithdraw);
	}

	@Override
	public String Wallettowallet(int account_number4, int reciever_account_number, double amount1) {
		// TODO Auto-generated method stub
		String str1= dao.Wallettowallet(account_number4,reciever_account_number,amount1);
		return str1;
	}

	@Override
	public String Accounttowallet(int account_number5, double amount11) {
		String str2= dao.Accounttowallet(account_number5,amount11);
		return str2;
	}

	@Override
	public String Wallettoaccount(int account_number6, double amount2) {
		String str3= dao.Wallettoaccount(account_number6,amount2);
		return str3;
	}

	@Override
	public List<Transaction> printtransaction(int account_number) {
		return dao.printtransaction(account_number);
			
		
	}

	

	
	


	}
