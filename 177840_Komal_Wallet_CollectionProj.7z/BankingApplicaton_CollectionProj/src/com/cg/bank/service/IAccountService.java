package com.cg.bank.service;

import java.util.List;
import java.util.Map;

import com.cg.bank.bean.Account;
import com.cg.bank.bean.Transaction;
import com.cg.bank.bean.Wallet;
import com.cg.bank.exception.AccountException;

public interface IAccountService {

	void validateUserName(String username) throws AccountException;

	void validatePassword(String password) throws AccountException;

	void validateMobileNo(String mobileNo) throws AccountException;

	void validateAccount_number(int account_number) throws AccountException;
	public void addnewAccount(Account a) throws AccountException;
	double getaccountbalance(int account_number1);

	double getwalletbalance(int account_number1);

	double deposite(int Account_number11, double depositeamount) throws AccountException;

	double withdraw(int account_number111, double amountwithdraw) throws AccountException;
	
	String Wallettowallet(int account_number4, int reciever_account_number, double amount1);

	String Accounttowallet(int account_number5, double amount11);

	String Wallettoaccount(int account_number6, double amount2);

	List<Transaction> printtransaction(int account_number);

	

	

}
