package com.cg.bank.dao;

import static org.junit.Assert.*;

import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.bank.bean.Account;
import com.cg.bank.exception.AccountException;

public class AccountDAOImplTest {
	AccountDAOImpl dao=null;

	@Before
	public void setUp() throws Exception {
		dao=new AccountDAOImpl();
	}

	@After
	public void tearDown() throws Exception {
		dao=null;
	}
/*
	@Test
	public void testAddnewAccount() {
		Account a = new Account("Komal", "12345", "9527192392");

		try {
			int Account_number = dao.addnewAccount(a);
			assertNotNull(Account_number);
		} catch (AccountException e) {
         System.out.println(e);
		}
	}
	public void testAddnewAccountNull() {
		Account a = new Account("Komal", "12345", "9527192392");

		try {
			int Account_number = dao.addnewAccount(a);
			assertNull(Account_number);
		} catch (AccountException e) {
         System.out.println(e);
		}
	}*/

	@Test
	public void testGetaccountbalance() {
		int account_number1=0;
		double account=dao.getaccountbalance(account_number1);
		assertNotNull(account);
		
	}

	@Test
	public void testGetwalletbalance() {
		int account_number1=0;
		double wallet=dao.getaccountbalance(account_number1);
		assertNotNull(wallet);
	}

	@Test
	public void testDeposite() {
		int account_number1=0;
		double account=dao.getaccountbalance(account_number1);
		assertNotNull(account);
	}

	@Test
	public void testWithdraw() {
		int account_number1=0;
		double account=dao.getaccountbalance(account_number1);
		assertNotNull(account);
	}

	@Test
	public void testWallettowallet() {
		int account_number1=0;
		double wallet=dao.getaccountbalance(account_number1);
		assertNotNull(wallet);
	}
	

	@Test
	public void testAccounttowallet() {
		int account_number1=0;
		double wallet=dao.getaccountbalance(account_number1);
		assertNotNull(wallet);
	}
	

	@Test
	public void testWallettoaccount() {
		int account_number1=0;
		double account=dao.getaccountbalance(account_number1);
		assertNotNull(account);
	}

}
