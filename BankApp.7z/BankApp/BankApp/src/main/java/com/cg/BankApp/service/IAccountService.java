package com.cg.BankApp.service;

import java.math.BigDecimal;

import com.cg.BankApp.entity.Account;

public interface IAccountService {
	public Account createAccount(Account customer);
	public double showBalance(String mobileNo);
	public boolean fundTransfer (String sourceMobileNo,String targetMobileNo,BigDecimal amount);
	public boolean depositAmount(String mobileNo,BigDecimal amount);
	public boolean withdrawAmount(String mobileNo,BigDecimal amount);
	public String validateNum(String mobileNo);
	
	

}
