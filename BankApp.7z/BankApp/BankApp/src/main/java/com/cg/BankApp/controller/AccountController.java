package com.cg.BankApp.controller;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.BankApp.entity.Account;
import com.cg.BankApp.service.IAccountService;

@RestController
public class AccountController {
	
	@Autowired
	private IAccountService service;
	
	@Autowired
	private Account account;
	
	@PostMapping(value="/createaccount")
	public Account createAccount(@RequestBody Account account) {
		return service.createAccount(account);
	}
	
	@GetMapping(value="/showbalance/{mobileNo}")
	public double showBalance(@PathVariable String mobileNo) {
		return service.showBalance(mobileNo);
		
	}
	@PostMapping(value="/deposite/{mobileNo}/{amount}")
	public void deposit(@PathVariable String mobileNo,@PathVariable BigDecimal amount) {
	 service.depositAmount(mobileNo, amount);
	}
	@PostMapping(value = "/withdraw/{mobileNo}/{amount}")
	public void withdraw(@PathVariable String mobileNo,@PathVariable BigDecimal amount) {
		System.out.println(mobileNo+"--"+amount.doubleValue());
		service.withdrawAmount(mobileNo, amount);
	}
	
	@PostMapping(value="/fundtransfer/{sourceMobileNo}/{targetMobileNo}/{amount}")
	public void fundT(@PathVariable String sourceMobileNo,@PathVariable String targetMobileNo,@PathVariable BigDecimal amount) {
	 service.fundTransfer(sourceMobileNo, targetMobileNo, amount);	
}
}