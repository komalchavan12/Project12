package com.cg.BankApp.dao;

import org.springframework.data.repository.CrudRepository;

import com.cg.BankApp.entity.Wallet;

public interface WalletRepository extends CrudRepository<Wallet, Integer>{

}
