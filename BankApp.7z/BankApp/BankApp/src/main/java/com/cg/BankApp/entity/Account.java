package com.cg.BankApp.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Table(name="acc_table")
@Component
public class Account {

	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "myseq")
	@SequenceGenerator(name = "myseq",sequenceName = "accountdataseq",initialValue =400,allocationSize = 1)
	private int accountNo;
	@Id
	private String mobileNo;
	private String name;
	@OneToOne(cascade = CascadeType.ALL) 
	@JoinColumn(name="walletId")
	private Wallet wallet;
	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Account(int accountNo, String mobileNo, String name, Wallet wallet) {
		super();
		this.accountNo = accountNo;
		this.mobileNo = mobileNo;
		this.name = name;
		this.wallet = wallet;
	}
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Wallet getWallet() {
		return wallet;
	}
	public void setWallet(Wallet wallet) {
		this.wallet = wallet;
	}
	@Override
	public String toString() {
		return "Account [accountNo=" + accountNo + ", mobileNo=" + mobileNo + ", name=" + name + ", wallet=" + wallet
				+ "]";
	}
	
}
