package com.cg.BankApp.service;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.BankApp.dao.AccountRepository;
import com.cg.BankApp.entity.Account;
import com.cg.BankApp.entity.Wallet;


@Service
public class AccountService implements IAccountService{

	@Autowired
    AccountRepository repo;
	
	@Autowired
	Wallet wallet;
	@Autowired
	Account account;
	
	@Override
	public Account createAccount(Account account) {
		Wallet w=new Wallet();
		w.setBalance(0.0);
		account.setWallet(w);
		return repo.save(account);
	}

	@Override
	public double showBalance(String mobileNo) {
		return repo.findById(mobileNo).get().getWallet().getBalance();
	}

	@Override
	public boolean fundTransfer(String sourceMobileNo, String targetMobileNo, BigDecimal amount) {
		System.out.println(sourceMobileNo+" "+targetMobileNo);
		Account sourceMobile=repo.findById(sourceMobileNo).get();
		System.out.println("Source"+sourceMobile);
		Account targetMobile=repo.findById(targetMobileNo).get();
		System.out.println("Target"+targetMobile);
		if(sourceMobile.getWallet().getBalance()<amount.doubleValue()) {
		return false;
		}else {
			Wallet targetWallet=targetMobile.getWallet();
			double targetBalance=targetWallet.getBalance();
			targetBalance=targetWallet.getBalance()+amount.doubleValue();
			targetWallet.setBalance(targetBalance);
			targetMobile.setWallet(targetWallet);
			
			Wallet sourceWallet=sourceMobile.getWallet();
			double sourcebalance=sourceWallet.getBalance();
			sourcebalance=sourceWallet.getBalance()-amount.doubleValue();
			sourceWallet.setBalance(sourcebalance);
			sourceMobile.setWallet(sourceWallet);
			repo.save(sourceMobile);
			repo.save(targetMobile);
			return true;

		}		
	}

	@Override
	public boolean depositAmount(String mobileNo, BigDecimal amount) {
		account=repo.findById(mobileNo).get();
		double balance=account.getWallet().getBalance()+amount.doubleValue();
		wallet=account.getWallet();
		wallet.setBalance(balance);
		account.setWallet(wallet);
		repo.save(account);
		return true;
	}

	@Override
	public boolean withdrawAmount(String mobileNo, BigDecimal amount) {
		account=repo.findById(mobileNo).get();
		if(account.getWallet().getBalance()<amount.doubleValue()) {
			return false;
		}
		
		else {
		double balance=account.getWallet().getBalance()-amount.doubleValue();
		wallet=account.getWallet();
		wallet.setBalance(balance);
		account.setWallet(wallet);
		repo.save(account);
		return true;
		}
	}

	@Override
	public String validateNum(String mobileNo) {
		String str;
		account= repo.findById(mobileNo).get();
		if(account!=null) {
			str="Mobileno exists";
		}else {
			str="new user";
		}
		return str;
	}

}
