package com.example.quoteapi.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;

@Entity
public class Quote {
	@Id
	private Long id;
	@NotNull
	private String author;
	private String quote;
	
	public Quote(Long id, String author, String quote) {
		super();
		this.id = id;
		this.author = author;
		this.quote = quote;
	}
	public Quote() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getQuote() {
		return quote;
	}
	public void setQuote(String quote) {
		this.quote = quote;
	}
	@Override
	public String toString() {
		return "quote [id=" + id + ", author=" + author + ", quote=" + quote + "]";
	}
	
	
}
