package com.example.quoteapi;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScans;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.quoteapi.entity.Quote;
import com.example.quoteapi.service.QuoteService;

@RestController
@SpringBootApplication
@ComponentScans(value = { @ComponentScan("com.example.quoteapi.Controller"),@ComponentScan("com.example.quoteapi.dao"),
@ComponentScan("com.example.quoteapi.entity"),@ComponentScan("com.example.quoteapi.service")})
public class QuoteapiApplication implements ErrorController,CommandLineRunner{
    
	@Autowired
	private QuoteService service;
	
	private static final String PATH="/error";
	public static void main(String[] args) {
		SpringApplication.run(QuoteapiApplication.class, args);
	}

	@GetMapping(value=PATH)
	public String error() {
		return PATH;
	}
	@Override
	public String getErrorPath() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void run(String... args) throws Exception {
		List<Quote> list=new ArrayList<Quote>(Arrays.asList(
				new Quote(11L,"Do or Die","Mahatma Gandhi"),new Quote(22L,"All is Well","Three Idiots")));
		service.saveQuotes(list);
	}

}
