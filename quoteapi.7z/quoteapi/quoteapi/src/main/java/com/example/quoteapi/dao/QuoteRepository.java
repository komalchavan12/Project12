package com.example.quoteapi.dao;

import org.springframework.data.repository.CrudRepository;

import com.example.quoteapi.entity.Quote;

public interface QuoteRepository extends CrudRepository<Quote,Long>{

}
