package com.cg.bank.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.bank.bean.Account;
import com.cg.bank.bean.Transaction;
import com.cg.bank.bean.Wallet;
import com.cg.bank.exception.AccountException;

public class AccountDAOImpl implements IAccountDAO {
	Map<Integer,Account> account=new HashMap<Integer,Account>();
	Map<Integer,Wallet> wallet=new HashMap<Integer,Wallet>();
	List<Transaction> transaction=new ArrayList<Transaction>(); 
	Wallet w=null;
	Account a=null;

	public void addnewAccount(Account a){
		account.put(a.getAccount_number(), a);	
		a.setBalance(0d);
		w=new Wallet(a.getAccount_number(),0);
		wallet.put(a.getAccount_number(), w);
		System.out.println(account);
		
	}
	@Override
	public double getaccountbalance(int account_number1) {
		// TODO Auto-generated method stub
		Account a=account.get(account_number1);
		return a.getBalance();
	}
	@Override
	public double getwalletbalance(int account_number1) {
		Wallet w=wallet.get(account_number1);
		return w.getWallet_Balance();
	}

	@Override
	public double deposite(int Account_number11, double amount) throws AccountException {
		double amountAfterDeposite=0;
		for(Account ac:account.values()) {
			System.out.println("account number:  "+ ac.getAccount_number());
			if(ac.getAccount_number()==Account_number11) {
				amountAfterDeposite=ac.getBalance()+amount;
				ac.setBalance(amountAfterDeposite);
				Transaction t=new Transaction(Account_number11,amount,LocalDate.now());
				transaction.add(t);
				break;
			}
			else{
				System.out.println("Enter Proper Account Number..");
				
			}
		}
		return amountAfterDeposite;
	}

	@Override
	public double withdraw(int account_number111, double amountwithdraw) throws AccountException {
		double amountAfterWithdraw=0;
		for(Account ac:account.values()) {
			System.out.println("account number:  "+ ac.getAccount_number());
			if(ac.getAccount_number()==account_number111) {
				amountAfterWithdraw=ac.getBalance()-amountwithdraw;
				ac.setBalance(amountAfterWithdraw);
				Transaction t=new Transaction(account_number111,amountwithdraw,LocalDate.now());
				transaction.add(t);
				break;
			}
			else{
				System.out.println("Enter Proper Account Number..");
				
			}
		}
		return amountAfterWithdraw;
	}
	@Override
	public String fundTransfer(int account_number4, int reciever_account_number, double amount1) {
		Double amountAfterWithdraw=0d;
		Double amountAfterDeposite=0d;
		for(Account ac:account.values()) {
			if(ac.getAccount_number()==account_number4) {
				 amountAfterWithdraw=ac.getBalance()-amount1;
				ac.setBalance( amountAfterWithdraw);
				Transaction t=new Transaction(account_number4,amount1,LocalDate.now());
				transaction.add(t);
				break;
			}
			
		}
		for(Account ac:account.values()) {
			if(ac.getAccount_number()==reciever_account_number) {
				amountAfterDeposite = ac.getBalance()+amount1;
				ac.setBalance(amountAfterDeposite);
				Transaction t=new Transaction(reciever_account_number,amount1,LocalDate.now());
				transaction.add(t);
				break;
			}
			
		}
		return "Transfered";
	}
	@Override
	public String Accounttowallet(int account_number5, double amount11) {
		Double Wallet_Balance=0d;
		Double amountAfterWithdraw=0d;
		for(Account ac:account.values()) {
			if(ac.getAccount_number()==account_number5) {
				 amountAfterWithdraw=ac.getBalance()-amount11;
				ac.setBalance( amountAfterWithdraw);
				break;
			}
		}
		for(Wallet w:wallet.values()) {
			if(w.getAccount_number()==account_number5) {
				Wallet_Balance= w.getWallet_Balance()+amount11;
				w.setWallet_Balance(Wallet_Balance);
				
				break;
			}
			
		}
		return "Transfered";
	}
	@Override
	public String Wallettoaccount(int account_number6, double amount2) {
		Double Wallet_Balance=0d;
		Double amountAfterWithdraw=0d;
		
		for(Wallet w:wallet.values()) {
			if(w.getAccount_number()==account_number6) {
				Wallet_Balance= w.getWallet_Balance()-amount2;
				w.setWallet_Balance(Wallet_Balance);
				
				break;
			}
			
		}
		for(Account ac:account.values()) {
			if(ac.getAccount_number()==account_number6) {
				 amountAfterWithdraw=ac.getBalance()+amount2;
				ac.setBalance( amountAfterWithdraw);
				break;
			}
		}
		return "Transfered";
	}
	@Override
	public List<Transaction> printtransaction(int account_number) {
		List<Transaction> list= new ArrayList<Transaction>();
		for(Transaction t:transaction)
			if(t.getAccount_number()==account_number) {
				list.add(t);
			}
		return list;
		
	}
	
	
	}

	

	
	


	

